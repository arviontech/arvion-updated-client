module.exports=[63336,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28publicRoute%29_blog_page_actions_9fecf4e9.js.map