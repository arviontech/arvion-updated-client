module.exports=[29283,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_social-links_page_actions_62d1b1db.js.map