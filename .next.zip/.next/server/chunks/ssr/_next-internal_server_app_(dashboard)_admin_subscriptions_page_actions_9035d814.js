module.exports=[63028,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_subscriptions_page_actions_9035d814.js.map