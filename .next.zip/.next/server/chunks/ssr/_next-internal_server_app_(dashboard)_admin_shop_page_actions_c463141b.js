module.exports=[55182,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_shop_page_actions_c463141b.js.map