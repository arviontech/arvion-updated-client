module.exports=[12498,a=>{"use strict";var b=a.i(7997);a.s(["default",0,({children:a})=>(0,b.jsx)(b.Fragment,{children:a})])}];

//# sourceMappingURL=app_%28auth%29_layout_tsx_2ffca1fc._.js.map