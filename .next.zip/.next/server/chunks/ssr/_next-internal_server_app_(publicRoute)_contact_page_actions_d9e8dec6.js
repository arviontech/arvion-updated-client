module.exports=[36757,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28publicRoute%29_contact_page_actions_d9e8dec6.js.map