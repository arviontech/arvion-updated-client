module.exports=[32356,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28publicRoute%29_projects_page_actions_2135c591.js.map