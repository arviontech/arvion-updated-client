module.exports=[60076,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28publicRoute%29_%5BserviceSlug%5D_page_actions_74ffd90f.js.map