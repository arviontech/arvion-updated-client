module.exports=[70335,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_page_actions_29e3fece.js.map