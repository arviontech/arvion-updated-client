module.exports=[76080,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_skills_page_actions_41c75d3c.js.map