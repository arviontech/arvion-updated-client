module.exports=[81485,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_projects_page_actions_db6c233d.js.map