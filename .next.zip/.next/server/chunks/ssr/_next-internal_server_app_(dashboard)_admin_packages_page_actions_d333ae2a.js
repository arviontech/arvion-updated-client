module.exports=[76990,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_admin_packages_page_actions_d333ae2a.js.map