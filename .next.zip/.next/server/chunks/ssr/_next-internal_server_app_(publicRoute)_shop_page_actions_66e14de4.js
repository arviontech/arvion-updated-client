module.exports=[67414,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28publicRoute%29_shop_page_actions_66e14de4.js.map