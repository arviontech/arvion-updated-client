globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/52ae7dc1d41a11d9.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/ee1d6c2535f08a49.js",
    "static/chunks/e3c838b1b5004803.js",
    "static/chunks/4b77dcde68464653.js",
    "static/chunks/turbopack-cb3a3d1a479234f6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];