var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/node_modules_next_6762cb56._.js")
R.c("server/chunks/[root-of-the-server]__3a9478e2._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)").exports
